<html>

<head>
<link rel="stylesheet" href="view.css" />
</head>

<body>

<div class="para">
<?php
$c = 0;
$accounts = mysql_connect("localhost" , "root" , "shikhu123") or die(mysql_error());

mysql_select_db('accounts' , $accounts);



if( ($_POST['uname']) and ($_POST['pwd']) )
{
$username = $_POST['uname'];
$pwd = $_POST['pwd'];


$sql = "SELECT * FROM voter";

$q = mysql_query($sql , $accounts);

while($row = mysql_fetch_array($q))
{
	if($row[0] == $username and $row[6] == $pwd)
	{
	$c = 1;	
	echo '<big><b><center> HELLO!!</center></b></big><br><br>';
	echo '
			<ul>
			<li>NAME		  : ' . $row[0] . '</li>
			<li>ADDRESS		  : ' . $row[1] . '</li>
			<li>DISTRICT	  : ' . $row[2] . '</li>
			<li>PHONE NO.	  : ' . $row[3] . '</li>
			<li>EMAIL ID	  : ' . $row[4] . '@'.$row[5].'</li>
			<li>GENDER		  : ' . $row[8] . '</li>
			<li>AGE			  : ' . $row[9] . '</li>
			<li>EXPECTATIONS  : ' . $row[10] . '</li>
	';
}
}
 if ($c != 1)
	header("Location: voterlog.php?msg4=<big><b><u>Incorrect password or username!!</u></b></big>");




}

else
{
header("Location: voterlog.php?msg3=<big><b><u>Please fill all the entries!!</u></b></big>");
}

?>
</div>

</body>
</html>
