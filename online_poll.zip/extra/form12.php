<html>
<head>
<title>
	Online National Polling
</title>
 <link rel="stylesheet" href="$form12.css" />
 
 <script>
	function validateForm() {
		var x = document.forms["myForm"]["pass"].value;
		var y = document.forms["myForm"]["Cpass"].value;
		var z = document.forms["myForm"]["age"].value;
		if (x != y) {
			alert("Error:passwords dont match");
        
		}
		if (z<18) {
			alert("Error:age should be greater than 18 years");
        
		}
		
	}
	
 </script>
 
</head>
<body>


<div class="para"><td>
<center><center><h3><b><big><u>Voter Registeration Form</u></big></b></h3></center>
<?php


	if(isset($_GET['msg']))
	{
		echo $_GET['msg'] ; 
	}
	if(isset($_GET['msg2']))
	{
		echo $_GET['msg2'] ; 
	}
	
?>



<p><center>
<form name = "myForm" action = "voter_reg.php" onSubmit = "validateForm()" method = "GET">
<div align="center">
<br>

Enter ur name: <input type="text" size="35" value="" name="name">
<br><br>
Enter ur address.: <input type="text" size="35" value="" name="add">
<br><br>
Enter ur district: <input type="text" size="35" value="" name="dist">
<br> <br>
Enter ur phone no.: +91 <input type="text" size="35" value="" name="ph">
<br><br>
Enter ur email id: <INPUT NAME="email">@<INPUT NAME="emailend">
<br> <br> 
Enter ur password: <input type="password" size="35" maxlength="8" value="" name="pass">(Must not be more than 8 char.)
<br><br>
Confirm ur password: <input type="password" size="35" maxlength="8" value="" name="Cpass">(Must not be more than 8 char.)
<br><br>

Gender:<br>
<input type="radio" name="gender" value="Male">
Male
<input type="radio" name="gender" value="Female">
Female
<br><br>
Age:<input type="text" size="35" name="age" value="valid-above 18">

<br><br>
Your expectations/demands from candidates:
<br>
<textarea cols="40" rows="5" name="exp">
</textarea>
<bR><br>


<center><input  type="Submit" value="Submit"><input type="Submit" value="Reset"><br><BR>

</td>
</table border>


</div>
</form>
</center></p>
 </div>



</body>
</html>