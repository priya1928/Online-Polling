<html>
<head>
<title>
	Online National Polling
</title>
 <link rel="stylesheet" href="$candlog.css" />
</head>
<body>

<div class="para">
<form action = "candfetch.php" method = "POST">
<center><b>welcome To Online National Polling</b></center>
<?php
	if (isset($_GET['msg5']))
		echo '<center>' . $_GET['msg5'] . '</center>';
	if (isset($_GET['msg6']))
		echo '<center>' . $_GET['msg6'] . '</center>';
?>
<p><center>

Enter ur name: <input type="text" size="35" name = "cname">
<br><br>
Enter ur password: <input type="password" size="35" maxlength="30" name = "cpwd">
<br><br>

<center><input  type="Submit" value="log in"><br><BR></center>
</form>
<br><br></center></p>
</FORM> </div>
 
 </body>
</html>