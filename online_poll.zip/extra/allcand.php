<html>

<head>
<link rel="stylesheet" href="view1.css" />
</head>

<body>

<div class="para">


<?php
$c = 0;
$accounts = mysql_connect("localhost" , "root" , "shikhu123") or die(mysql_error());

mysql_select_db('accounts' , $accounts);

$sql = "SELECT * FROM candidate";

$q = mysql_query($sql , $accounts);

echo '<big><b><center> HELLO!!</center></b></big><br><br>';
while($row = mysql_fetch_array($q))
{
	$c = $c + 1;
	echo 'CANDIDATE '.$c.':';
	
	echo '
			<ul>
			<li>NAME		   : ' . $row[0] . '</li>
			<li>ADDRESS		   : ' . $row[1] . '</li>
			<li>DISTRICT	   : ' . $row[2] . '</li>
			<li>PHONE NO.	   : ' . $row[3] . '</li>
			<li>EMAIL ID	   : ' . $row[4] . '@'.$row[5].'</li>
			<li>GENDER		   : ' . $row[8] . '</li>
			<li>AGE			   : ' . $row[9] . '</li>
			<li>QUALIFICATION  : ' . $row[10] . '</li>
			<li>PARTY		   : ' . $row[11] . '</li>
			<li>POST           : ' . $row[12] . '</li>
			<li>AGENDA         : ' . $row[13] . '</li>
	';
	echo '<br><br>';
}

?>
</div>

</body>
</html>

