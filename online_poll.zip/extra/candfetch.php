<html>

<head>
<link rel="stylesheet" href="view.css" />
</head>

<body>

<div class="para">

<?php

$accounts = mysql_connect("localhost" , "root" , "shikhu123") or die(mysql_error());

mysql_select_db('accounts' , $accounts);



if( $_POST['cname'] and $_POST['cpwd'] )
{
$uname = $_POST['cname'];
$pwd = $_POST['cpwd'];


$sql = "SELECT * FROM candidate";

$q = mysql_query($sql , $accounts);

while($row = mysql_fetch_array($q))
{
	if($row[0] == $uname and $row[6] == $pwd)
	{
	$c = 1;	
	echo '<big><b><center> HELLO!!</center></b></big><br><br>';
	echo '
			<ul>
			<li>NAME		   : ' . $row[0] . '</li>
			<li>ADDRESS		   : ' . $row[1] . '</li>
			<li>DISTRICT	   : ' . $row[2] . '</li>
			<li>PHONE NO.	   : ' . $row[3] . '</li>
			<li>EMAIL ID	   : ' . $row[4] . '@'.$row[5].'</li>
			<li>GENDER		   : ' . $row[8] . '</li>
			<li>AGE			   : ' . $row[9] . '</li>
			<li>QUALIFICATION  : ' . $row[10] . '</li>
			<li>PARTY		   : ' . $row[11] . '</li>
			<li>POST           : ' . $row[12] . '</li>
			<li>AGENDA         : ' . $row[13] . '</li>
	';
}
}
if ($c != 1)
	header("Location: candlog.php?msg5=<big><b><u>Incorrect password or username!!$pwd $uname '.$row[0].' '.$row[6].'</u></b></big>");




}

else
{
header("Location: candlog.php?msg6=<big><b><u>Please fill all the entries!!</u></b></big>");
}

?>
</div>

</body>
</html>


