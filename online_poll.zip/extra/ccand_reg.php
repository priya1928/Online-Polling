<?php

$accounts = mysql_connect("localhost" , "root" , "shikhu123") or die(mysql_error());

mysql_select_db('accounts' , $accounts);

if( ($_POST['name']) and ($_POST['add']) and ($_POST['dist']) and ($_POST['ph']) and ($_POST['email']) and ($_POST['emailend']) and
	 ($_POST['pass']) and ($_POST['Cpass']) and ($_POST['gender']) and ($_POST['age']) and ($_POST['quali']) and ($_POST['party']) and ($_POST['post']) and ($_POST['agenda']))
	 {

$n = $_POST['name'];
$a = $_POST['add'];
$d = $_POST['dist'];
$p = $_POST['ph'];
$e = $_POST['email'];
$ee = $_POST['emailend'];
$pass = $_POST['pass'];
$cpass = $_POST['Cpass'];
$g = $_POST['gender'];
$age = $_POST['age'];
$q = $_POST['quali'];
$py = $_POST['party'];
$post = $_POST['post'];
$agenda = $_POST['agenda'];

$sql = "INSERT INTO candidate values('$n' , '$a' , '$d' , '$p' , '$e' , '$ee' , '$pass' , '$cpass' , '$g' ,'$age' , '$q' , '$py' , '$post' , '$agenda')";


$q = mysql_query($sql , $accounts);

if (!$q)
	echo mysql_error();
else
	header("Location: candidate.php?msg1=You are registered Successfully");


		
	  }
	else{
		header("Location: candidate.php?msg=Please fill all the entries!!");
		}
		

?>