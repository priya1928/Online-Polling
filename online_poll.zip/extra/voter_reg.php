<?php

$accounts = mysql_connect("localhost" , "root" , "shikhu123") or die(mysql_error());

mysql_select_db('accounts' , $accounts);

if( isset($_GET['name']) and isset($_GET['add']) and isset($_GET['dist']) and isset($_GET['ph']) and isset($_GET['email']) and isset($_GET['emailend']) and
	 isset($_GET['pass']) and isset($_GET['Cpass']) and isset($_GET['gender']) and isset($_GET['age']) and isset($_GET['exp']))
	 {

$n = $_GET['name'];
$a = $_GET['add'];
$d = $_GET['dist'];
$p = $_GET['ph'];
$e = $_GET['email'];
$ee = $_GET['emailend'];
$pass = $_GET['pass'];
$cpass = $_GET['Cpass'];
$g = $_GET['gender'];
$age = $_GET['age'];
$exp = $_GET['exp'];


$sql = "INSERT INTO voter values('$n' , '$a' , '$d' , '$p' , '$e' , '$ee' , '$pass' , '$cpass' , '$g' ,'$age' , '$exp')";


$q = mysql_query($sql , $accounts);



		header("Location: form12.php?msg2=<U><b><big>U HAVE BEEN SUCCESSFULLY REGISTERED!!</big></b></U>");
	  }
else{
		header("Location: form12.php?msg=<U><b><big>Please fill all the entries!!</big></b></U>");
		}
		
if(!$q)
{
echo mysql_error();
}
else

echo 'success';

?>