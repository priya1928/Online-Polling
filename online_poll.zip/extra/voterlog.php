<html>
<head>
<title>
	Online National Polling
</title>
 <link rel="stylesheet" href="$voterlog.css" />
</head>
<body>

<div class="para">
<form action= "votefetch.php" method="POST">
<center><b>welcome To Online National Polling</b></center>
<?php
	if (isset($_GET['msg3']))
		echo '<center>' . $_GET['msg3'] . '</center>';
	if (isset($_GET['msg4']))
		echo '<center>' . $_GET['msg4'] . '</center>';
?>
<p><center>
Enter ur name: <input type="text" size="35" name="uname">
<br><br>
Enter ur password: <input type="password" size="35" maxlength="20" name="pwd">
<br><br>

<center><input  type="Submit" value="Submit"><input type="Submit" value="Reset"><br><BR></center>
<br><br></center></p>
 </form>
 </div>
 
 </body>
</html>