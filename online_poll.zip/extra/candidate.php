<html>
<head>
<title>
	Online National Polling
</title>
 <link rel="stylesheet" href="$cand.css" />
 
 <script>
	function validateForm() {
		var x = document.forms["myForm"]["pass"].value;
		var y = document.forms["myForm"]["Cpass"].value;
		var z = document.forms["myForm"]["age"].value;
		if (x != y) {
			alert("Error:passwords dont match");
        
		}
		if (z<18) {
			alert("Error:age should be greater than 18 years");
        
		}
		
	}
	
 </script>
 
 
</head>
<body>


<div class="para"><td>
<center><center><h3><b><big><u>Candidate Registeration Form</u></big></b></h3></center>

<?php


	if(isset($_GET['msg']))
	{
		echo $_GET['msg'] ; 
	}
	if(isset($_GET['msg1']))
	{
		echo $_GET['msg1'] ; 
	}
	
?>

<p><center>
<form  name = "myForm" action = "ccand_reg.php" onsubmit = "validateForm()" method = "POST">
<div align="center">
<br>

Enter ur name: <input type="text" size="35" value="" name="name">
<br><br>
Enter ur address.: <input type="text" size="35" value="" name="add">
<br><br>
Enter ur district: <input type="text" size="35" value="" name="dist">
<br> <br>
Enter ur phone no.: +91 <input type="text" size="35" value="" name="ph">
<br><br>
Enter ur email id: <INPUT NAME="email">@<INPUT NAME="emailend">
<br> <br> 

Enter ur password: <input type="password" size="35" maxlength="8" value="" name="pass">(Must not be more than 8 char.)
<br><br>
Confirm ur password: <input type="password" size="35" maxlength="8" value="" name="Cpass">(Must not be more than 8 char.)
<br><br>

Gender:<br>
<input type="radio" name="gender" value="Male">
Male
<input type="radio" name="gender" value="Female">
Female
<br><br>
Age:<input type="text" size="35" name="age" value="valid-above 18">

<br><br>


Qualification:<input type="text" size="35" value="" name="quali">
<bR><br>

Political Party:<input type="text" size="35" value="" name="party">
<bR><br>

Post:<input type="text" size="35" value="" name="post">
<bR><br>

Your agendas/Priority sectors of your focus if win:
<br>
<textarea cols="40" rows="5" name="agenda">
</textarea>
<bR><br>

<center><input  type="submit" value="Submit" ><input type="Submit" value="Reset"><br><BR>
</td>
</table border>

<?php

	if(isset($_GET['msg']))
	{
		echo $_GET['msg'] ; 
	}
	
?>

</div>
</form>
</center></p>
 </div>


